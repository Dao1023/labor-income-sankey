# 利润析视 Profit Bridge

> **10 秒看清一家巨头怎么赚钱：分部收入 → 利润桥 → 净利润，20 余年商业史一图流。**
>
> **English**: See how a tech giant actually makes money — segment revenue flowing through a proportional Sankey "profit bridge" down to net income.

**[🌐 在线体验 → https://dao1023.github.io/profitbridge/](https://dao1023.github.io/profitbridge/)**　·　无需安装，点开即用

![NVDA 占比+环比模式](docs/screenshots/nvda_pct_qoq.png)

## 为什么值得一看

- 🌉 **利润桥桑基图** — 营收 → 毛利 → 营业利润 → 净利润，钱从哪来、被谁吃掉、剩多少，流宽即金额，一眼看穿。
- 📊 **全历史柱状图** — 任选科目/分部，2003 → 2026 逐季时间序列，**无断季、无空洞**。
- 🎚️ **占比 / 环比一键切换** — 看结构（占营收 %）或看动能（QoQ 变化），不用碰 Excel。
- 🏛️ **每个数字可溯源** — 美股来自 SEC EDGAR XBRL 真实申报，港/A/韩/台/欧股来自交易所与权威聚合源，不是拍脑袋。
- 💱 **多币种多频次** — 92 家、7 个市场、申报本位币入库；年度看同比、港混频不跨期环比，口径不撒谎。
- 🫥 **缺数据就留白** — 不编数、不插值。没披露的季度诚实空着，这是工程诚信，不是缺陷。
- ⚡ **纯前端零构建** — 无框架、无 npm install，克隆或点开链接即可运行。

## 覆盖范围

**92 家公司 · 3,739 期（3,361 单季 + 331 年度 + 47 中期） · 7 个市场**（实测统计自合并后 `data/profit.json`，2026-11-20）。美股条目无 64 季封顶，为 EDGAR XBRL 完整连续历史（AAPL 72 季、MSFT 77 季、CSCO 73 季等）；SPCX（SpaceX）IPO 后仅 2 季、CRWV 与 CBRS 同样低于 12 季护栏，均经豁免入主序列并标注短历史；7 期尾端缺口（V/KO/NXPI 10-Q、SONY/TSM/TME/DIDIY 20-F）已从 filing 内嵌 iXBRL 实抓补齐（SEC companyfacts 未收录该批申报财务 facts）。覆盖审计（2026-11-01）另记录 2 家共 3 期缺口：CBRS 缺 2 期、00151.HK 缺 FY2018，如实留白、不插值。

| 市场 | 公司数 | 期数 | 口径 |
| --- | --- | --- | --- |
| 美股（EDGAR 季度 10-Q/10-K） | 31 | 1,648q | USD-M，Q4=FY−Q1..Q3；SPCX（SpaceX）2026-06 IPO 后仅披露 2 季，低于 minKeep=12 经豁免单独收录 |
| 年度申报（20-F/年报：阿里/百度/京东/拼多多/瑞幸/TSM/DIDIY/ASML/ARM/SPOT/STM/SONY/NESN/MC/华为/乐高 等） | 25 | 605 期（年度 271 + 单季 322 + 中期 12） | 申报本位币（CNY/TWD/EUR/CHF/JPY/DKK-M），frequency 为 annual / mixed |
| 港股（HKEX/东财，累计期差分为单季） | 17 | 723 期（单季 643 + 年度 45 + 中期 35） | CNY-M，frequency:'hk-mixed'，联想为 USD 单季 18q；02513/00100 为累计口径未差分 |
| 韩股（stockanalysis/fnguide 独立单季） | 3 | 61 期（单季 46 + 年度 15） | KRW-M，frequency:'mixed' |
| A 股（东财，真单季） | 14 | 673q | CNY-M |
| 台股（TWSE 季度） | 2 | 29q | USD-M（存已折算的美元值，非台币原值；2330.TW 与 TSM 年度条目并存，口径互见、禁跨条目环比） |

界面支持中英切换、多币种显示（CNY-M 可切 ¥/US$，其余币种按各期末汇率自动折算 USD 展示）、年度序列「环比」自动改为「同比」、hk-mixed 序列环比不跨 periodType，图表可一键导出 SVG / PNG。

### 数据来源分层

- **SEC EDGAR XBRL**：美股季度（80–100 天连续性护栏）+ 外国发行人 20-F 年度（300–400 天）+ 分部 R 文件；
- **HKEX/东财**：港股利润表（仅营收+净利润，累计期差分为单季；差分后营收为负的期如实置 null 并在 notes 标注）；
- **东财**：A 股单季（CNY-M）；
- **stockanalysis / fnguide / TWSE**：韩股、台股、欧股（雀巢/LVMH 年度、台积电 ADR 外的台股季度）。

### 数据整合管线（scripts/merge_batches.mjs）

`node scripts/merge_batches.mjs` 用 glob 加载**全部** `data/staging/batch*.json`（缺号 FATAL），再叠加 `fixups.json` 与磁盘优先 reconcile，合并进 `data/profit.json` + `data/companies.json`。使用边界：

- **不是从零重建**：脚本加载磁盘现有 profit.json，只覆写 staging 覆盖的 ticker；重建丢掉的 gross/opInc/rd/sga 由 reconcile 按磁盘原键序补回，其余条目（含全部手工修复）原样保留；**从不修改 data/staging/**。
- **先 dry 后写**：`node scripts/merge_batches.mjs --dry`（或 `DRY=1`）只打印报告不写盘。
- **定向/沙盒**：`--out-dir=DIR`（必须等号）写沙盒；`--batch-only=batchN` / `--fixup-ticker=XXXX` 只对指定 batch / 公司做增量补丁，其余零改动。
- **防回滚护栏**：写盘前逐条目对比合并结果与磁盘原版（公司数/期数/币种/期型/逐期数值），任何回滚都会 **exit 1 且不写盘**，差异摘要见 `tmp-merge/merge_report.json`；确属有意刷数时加 `--force` 显式放行。
- **修复层 `data/staging/fixups.json`**：batch 整合后直接修进 profit.json 的手工修复（mixed 季度回填 BABA/BIDU/DIDIY/JD/LKNCY/PDD/TCOM/TSM 等）已反写进该文件，管线在所有 batch 之后以最高优先级应用，保证全量重跑与磁盘修复版一致。
- 手工修复的正确流向是**反写进 staging**（batch*.json 或 fixups.json，磁盘为准），而不是 `--force` 硬压。

### Skipped 名单（如实不收录）

- **TCEHY / XIACF**：非 SEC 注册主体（EDGAR 无对应申报，财务仅在港交所披露），不在 EDGAR 数据范围内；
- **（更正）02513.HK（Z.AI）/ 00100.HK（MiniMax）**：此前以「可差分单季不足 8 季」为由不收录；2026-10-27 起改按短历史规则——有多少正式披露期就收多少、不设最低期数——已分别收录 7 / 8 期（累计口径未差分）。

## 已知口径差异

少数数据源存在口径差异——分部营收含内部交易未抵销（如 JD +5~6%）、营业利润含研发/销售管理之外的其他经营费用（如 STM 35 期中位 |残差/毛利| 2.65%，MSI/HPQ/AVGO/AMD/NXPI/SONY 等亦在 4~19%）、年度申报只单列研发（如 NTES 年度无法用「毛利−研发−销售管理」反推营业利润）、港股同一差分期末 gross/opInc 与 revenue/netInc 两套算法（如 00981.HK，差 <1%）等。本项目按「如实呈现、不强行抹平」原则**只标注、不改数**，逐条实测数字与原因见 [docs/KNOWN_CAVEATS.md](docs/KNOWN_CAVEATS.md)。负毛利等真实业务不在此列。

非自然财年（联想 3-31 财年）的年度分部只应与年内 4 季之和比较，直接对单季会得到 ≈4× 的假差——这是比较口径问题，前端累计视图已处理，不属于数据差异。

> **历史结论已修正（2026-11-20 复核）**：此处曾记载「雀巢 / LVMH 分部以本位币存储、前端按 USD 折算，图上假差 11–18%」。复核证明真因是**汇率被重复换算一次**——`assemble_d2.py` 产出的分部金额已折算 USD，`c20be5d` 又乘了一遍快照汇率（NESN 1.21274155、MC 1.12091287），并非本位币存储问题。该 bug 已由 `61d347d` 修复；修复后分部合计/营收比 NESN.SW 为 0.99622 / 0.99601 / 0.99561（2023–2025），MC.PA 为 1.00000（2022–2025 四期），不再是口径差异。教训是「同币种比值≈1」会掩盖双重换算——详见 KNOWN_CAVEATS 第五节与 `audits/2026-11-20/README.md`。

## 快速开始

1. **在线用**：直接打开 [https://dao1023.github.io/profitbridge/](https://dao1023.github.io/profitbridge/)；
2. **本地跑**：双击 `start.bat`（或 `node scripts/serve.mjs 8440`），浏览器打开 <http://127.0.0.1:8440/>；
3. **自托管**：本仓库是纯静态站点，GitHub Pages 选 `main / (root)` 即可，无任何构建步骤。

---

## 附录：数据口径与工程细节

<details>
<summary><b>数据来源与口径</b></summary>

- 来源：**SEC EDGAR XBRL companyfacts API**（美股利润表）+ **EDGAR 申报的分部 R 文件**（FilingSummary.xml → R\*.htm）+ **HKEX/东财/stockanalysis/TWSE**（港股、A股、韩股、台股、欧股，详见上方来源分层）。
- **Q4 由 FY − Q1..Q3 推导**（SEC 申报的是 YTD 累计值；港股累计期同理差分为单季）。
- 护栏按频次类适配：美股季度 **80–100 天**、年度 **300–400 天**、hk-mixed 按 periodType 分组各自校验（annual 300–400d、单季 70–250d）；并做利润链自洽校验（各桥节点可加合，有 gross 的家 gross≤revenue）。
- **缺失的科目/分部如实留空，不编造**：不申报毛利的公司（GOOGL/AMZN/META/ORCL）桑基自动切换结构；无分部披露的季度在数据 `notes` 中逐一列明；分部对不上营收的季度直接丢弃（`failures` 记录原因与原文出处）。
- **INTC**：Intel Foundry 模式下分部收入含内部销售，无干净的外部收入拆分 → 标记为 `degraded`，前端诚实降级展示。
- **TSM**：20-F 只有年度 ifrs-full 数据 → 以 TWD-M 11 财年条目收录（2015–2025；2020–2023 年 frankfurter 无 TWD 汇率，按邻近区间迭代逼近补齐，notes 标 `fxApprox`）；台股 2330.TW 季度条目独立并存，禁跨条目环比。
- **非经营性收益节点**：当净利润 > 营业利润时出现，数值 = 净利润 − 营业利润。GOOGL 2026 Q2 实例：NetIncomeLoss $112.19B、OperatingIncomeLoss $40.77B，桥内 71.42 自洽（已核对 10-Q frame CY2026Q2 原始 XBRL）。
- **多币种口径**：各条目 `currency` 为申报本位币（如 CNY-M/TWD-M/KRW-M）；前端默认按各期期末汇率折算 USD 显示（CNY-M 条目可手动切回 ¥ 原币）。批次内已带期末汇率；TSM 2020–2023 年汇率以邻近区间迭代逼近补齐（frankfurter 无 TWD 该区间数据），并在 notes 标注。
- 数值单位：百万（各条目申报本位币 -M；显示层按上条折算）。

</details>

<details>
<summary><b>利润桥实现</b></summary>

- 手写 SVG 桑基图，单一公共比例尺（px/$），流宽误差 < 1%；
- hover tooltip 显示精确金额与占比/环比。

</details>

<details>
<summary><b>更新数据</b></summary>

```powershell
$env:NODE_USE_ENV_PROXY="1"; $env:HTTPS_PROXY="http://127.0.0.1:7897"   # 如需代理
node scripts/fetch_profit.mjs    # 利润表 → data/profit.json + data/profit.json.js
node scripts/fetch_segments.mjs  # 分部 → data/segments.json
node scripts/validate_profit.mjs # 口径校验
```

`data/profit.json.js` 是 `profit.json` 的 JSONP 内联副本（`window.__PROFIT_DATA`），仅供 file:// 双击打开时兜底；正常走 HTTP 时前端 `fetch` 同目录 JSON。

</details>

<details>
<summary><b>目录结构与脚本</b></summary>

```
index.html / app.js    站点（原生 JS + vendor/echarts.min.js（5.5.1））
data/                  profit.json / segments.json / companies.json / logos/
scripts/               serve.mjs（零依赖静态服务器）、fetch_profit.mjs、
                       fetch_segments.mjs、validate_profit.mjs、
                       verify_profit_fix.mjs、verify_segments_hist.mjs（回归）
tests/                 verify_*.mjs（29 个，含 verify_scan.mjs；无头 CDP + 数据回归：柱状图/模式/时间轴/导出/币种/单位护栏等，
                       需先起 :8440 服务；截图与浏览器 profile 落在 tests/.shots、tests/.chrome）
docs/screenshots/      README 配图
```

> 版本注记：`vendor/echarts.min.js` 运行时自报 `5.5.1`（`node -e "require('./vendor/echarts.min.js').version"` → `5.5.1`；文件内 `t.version="5.5.1"` 唯一一处）。文件里另有 `version:"5.6.0"`，它落在随包 zrender 的命名空间对象与 `dependencies={zrender:"5.6.0"}` 声明上，不是 ECharts 版本。仓库 `app.js:3` 注释与 `audits/2026-11-01/A5-engineering` 里写的 v5.6.0 属过时/错误记录，以 vendor 运行时自报的 5.5.1 为准。

</details>

## License

数据来自各公司公开申报与交易所披露（SEC EDGAR 公有领域数据、HKEX、东方财富、TWSE、stockanalysis/fnguide 及公司年报等），仅供研究参考。代码 MIT。

## 第三方许可 / Third-party licenses

本站唯一随包分发的第三方库是 **Apache ECharts 5.5.1**（`vendor/echarts.min.js`），以 **Apache License 2.0** 许可分发：

| 组件 | 版本 | 许可 | 声明文件 |
| --- | --- | --- | --- |
| Apache ECharts | 5.5.1 | Apache-2.0 | 许可全文 [`vendor/echarts.LICENSE.txt`](vendor/echarts.LICENSE.txt) · 版权与组件声明 [`vendor/NOTICE`](vendor/NOTICE) |

`vendor/echarts.min.js` 为官方发行版原样文件（**Unmodified**）。其 bundle 内另含 ZRender 5.6.0（BSD-3-Clause）、tslib（0BSD），以及 treemap / tree / force 布局的 d3.js 派生代码（BSD-3-Clause，许可全文 [`vendor/licenses/LICENSE-d3.txt`](vendor/licenses/LICENSE-d3.txt)），声明见 `vendor/NOTICE`。除 ECharts 外，站点不加载其它第三方运行时依赖（`index.html` 仅引用 `vendor/echarts.min.js` 与本站 `app.js`）。
